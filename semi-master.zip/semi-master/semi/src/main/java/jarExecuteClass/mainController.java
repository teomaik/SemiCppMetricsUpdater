package jarExecuteClass;

import java.io.File;
import java.util.ArrayList;

import AST.ClassParser;
import clustering.cluster.Opportunity;
import db.DbController;
import gui.Analyser;
import gui.MethodOppExtractor;
import gui.MethodOppExtractorSettings;
import parsers.CodeFile;
import parsers.cFile;
import parsers.fortranFile;
import splitlongmethod.JavaClass;
import splitlongmethod.Method;

public class mainController {

	DbController dbCon;

	private String projectName;
	private String projectProgramingLanguage;
	private String projectDirectoryPath;
	private String credPath;
	
	private ArrayList<JavaClass> classResults = new ArrayList<>();
	private String selected_metric = "SIZE";// "LCOM1", "LCOM2", "LCOM4", "COH", "CC" //***???

	private int number_of_refs = 0;

	// Fortran, Fortran90, C, Cpp projects
	private ArrayList<CodeFile> projectFiles = new ArrayList<>();

	// Java projects
	private ArrayList<File> java_source_files = new ArrayList<>();
	private Analyser analyser;
	JavaClass javaClass;
	public static boolean DebugMode = false;
	public MethodOppExtractorSettings extractor_settings;
	public static String cohesion_metric = "LCOM2";
	public static int cohesion_metric_index = 2;

	public mainController(String type, String projectName, String directoryPath, String dbCredPath) {
		credPath = dbCredPath;
		dbCon = new DbController(dbCredPath);
		if(!dbCon.isReady()) {
			return;
		}
		this.projectProgramingLanguage = type;
		this.projectName = projectName;
		this.projectDirectoryPath = directoryPath;
		this.extractor_settings = new MethodOppExtractorSettings();

		analyser = new Analyser();

		
	}
	public boolean runExperiment() {
		
		if(!this.dbCon.isReady()) {
			System.out.println("Problem with databaseConnection");
			return false;
		}

		dbCon.closeConn();
		
		boolean commit = true;

		switch (projectProgramingLanguage) { 
		case "java":
			commit = getFilesForAnalysis_Java(projectDirectoryPath);
			break;
		case "c":
			commit = getFilesForAnalysis_C(projectDirectoryPath);
			break;
		case "cpp":
			commit = getFilesForAnalysis_C(projectDirectoryPath);
			break;
		case "f":
			commit = getFilesForAnalysis_F(projectDirectoryPath);
			break;
		case "f90":
			commit = getFilesForAnalysis_F(projectDirectoryPath);
			break;

		default:
			System.out.println("wrong argument for Programing Language (java, c, f, f90)");
		}
		
		
		dbCon.getNewConnection(credPath);

		if(!this.dbCon.isReady()) {
			System.out.println("Problem with databaseConnection");
			return false;
		}
		dbCon.deletePreviousInsertsOfProject(projectName);
		commit = commit && dbCon.doInserts();
		
		if(commit) {
			
			dbCon.connCommitAndClose();
			System.out.println("FIN!");
			return true;
		}else {
			dbCon.connRollBackAndClose();
			return false;
		}
	}

	private String getMeCorrectNameFormat(String oldName) {
		String retName = oldName;
		String[] splited = projectDirectoryPath.split(File.separator);
		String baseDirectory = splited[splited.length - 1];
		retName = retName.replaceFirst(projectDirectoryPath, baseDirectory);

		return retName;
	}

	private boolean doAnalysis(File file) {
		//***************************************************************************************************
		// <
		boolean ret = true;

		
		analyser.setFile(file);
		classResults.add(analyser.performAnalysis());
		
		JavaClass clazz = classResults.get(classResults.size()-1);

		for (int index = 0; index < clazz.getMethods().size(); index++) {
            boolean needsRefactoring = clazz.getMethods().get(index).needsRefactoring(selected_metric);	
            
            
            if(needsRefactoring) {
            	
            	String className = file.getName().replaceFirst("./", "");
            	String classPath = getMeCorrectNameFormat(file.getAbsolutePath()); 
            	String methodName = clazz.getMethods().get(index).getName();
            	
            	MethodOppExtractor extractor = new MethodOppExtractor(file, clazz.getMethods().get(index).getName(), extractor_settings, classResults.get(classResults.size()-1));

            	Method method = clazz.getMethods().getMethodByName(methodName);
            	ArrayList<Opportunity> opportunities = method.getOpportunityList().getOptimals();
            	
            	int count=1;
            	for(Opportunity opp : opportunities) {
            		if(count>1) {
        				break;
        			}
            		number_of_refs++;
            		ret = ret && dbCon.insertMethodToDatabase(projectName, className, methodName, opp.getStartLineCluster(), opp.getEndLineCluster(), opp.getOpportunityBenefitMetricByName("lcom2"), method.getMetricIndexFromName("lcom2"), method.getMetricIndexFromName("size"), classPath);
            		count++;
            	}
            }
        }
		File fileDel = new File("./" + file.getName() + "_parsed.txt"); 
        //ystem.out.println("./" + file.getName() + "_parsed.txt");
        fileDel.delete();
		// >
		//***************************************************************************************************
		return ret;
	}

	public boolean getFilesForAnalysis_Java(String directoryPath) {

		boolean ret = true;
		
		File directory = new File(directoryPath);

		// Get all files from a directory.
		File[] fList = directory.listFiles();
		if (fList != null) {
			for (File file : fList) {
				if (file.isFile() && file.getName().contains(".") && file.getName().charAt(0) != '.') {
					String[] str = file.getName().split("\\.");
					// For all the filles of this dirrecory get the extension
					if (str[str.length - 1].equalsIgnoreCase("java")) {
						java_source_files.add(file);

						ClassParser parser = new ClassParser(file.getAbsolutePath());
						parser.parse();
						utils.Utilities.writeCSV("./" + file.getName() + "_parsed.txt", parser.getOutput(), false);
						// ***************************************************************************************************
						// <
						ret = ret && doAnalysis(file);
						// >
						// ***************************************************************************************************
					}
				} else if (file.isDirectory()) {
					ret = ret && getFilesForAnalysis_Java(file.getAbsolutePath());
				}
			}
		}
		return ret;
	}

	public boolean getFilesForAnalysis_C(String directoryName) {
		System.out.println("directory name = "+directoryName);
		boolean ret = true;
		File directory = new File(directoryName);
		// Get all files from a directory.
		File[] fList = directory.listFiles();
		if (fList != null) {
			for (File file : fList) {
				if (file.isFile() && file.getName().contains(".") && file.getName().charAt(0) != '.') {
					String[] str = file.getName().split("\\.");
					// For all the filles of this dirrecory get the extension
					if (str[str.length - 1].equalsIgnoreCase("c")) {
						projectFiles.add(new cFile(file));

//System.out.println("file name = "+file.getName());
						projectFiles.get(projectFiles.size() - 1).parse();
						// ***************************************************************************************************
						// <
						ret = ret && doAnalysis(file);
						// >
						// ***************************************************************************************************

					}else if (str[str.length - 1].equalsIgnoreCase("cpp")) {
						projectFiles.add(new cFile(file));

//System.out.println("file name = "+file.getName());
						projectFiles.get(projectFiles.size() - 1).parse();
						// ***************************************************************************************************
						// <
						ret = ret && doAnalysis(file);
						// >
						// ***************************************************************************************************

					}
					//// it will run, but not correct .txt output for parameters
					// else if(str[str.length-1].equalsIgnoreCase("cpp") )
					// projectFiles.add(new cFile(file));
				} else if (file.isDirectory()) {
					ret = ret && getFilesForAnalysis_C(file.getAbsolutePath());
				}
			}
		}

		return ret;
	}
	public boolean getFilesForAnalysis_F(String directoryName) {
		System.out.println("directory name = "+directoryName);
		boolean ret = true;
		File directory = new File(directoryName);
		// Get all files from a directory.
		File[] fList = directory.listFiles();
		if (fList != null) {
			for (File file : fList) {
				if (file.isFile() && file.getName().contains(".") && file.getName().charAt(0) != '.') {
					String[] str = file.getName().split("\\.");
					// For all the filles of this dirrecory get the extension
					if (str[str.length - 1].equalsIgnoreCase("F90")) {

						projectFiles.add(new fortranFile(file, true));
						projectFiles.get(projectFiles.size() - 1).parse();
						// ***************************************************************************************************
						// <
						ret = ret && doAnalysis(file);
						// >
						// ***************************************************************************************************

					} else if (str[str.length - 1].equalsIgnoreCase("f") || str[str.length - 1].equalsIgnoreCase("f77")
							|| str[str.length - 1].equalsIgnoreCase("for")
							|| str[str.length - 1].equalsIgnoreCase("fpp")
							|| str[str.length - 1].equalsIgnoreCase("ftn")) {

						projectFiles.add(new fortranFile(file, false));
						projectFiles.get(projectFiles.size() - 1).parse();
						// ***************************************************************************************************
						// <
						ret = ret && doAnalysis(file);
						// >
						// ***************************************************************************************************

					}
					//// it will run, but not correct .txt output for parameters
					// else if(str[str.length-1].equalsIgnoreCase("cpp") )
					// projectFiles.add(new cFile(file));
				} else if (file.isDirectory()) {
					ret = ret && getFilesForAnalysis_C(file.getAbsolutePath());
				}
			}
		}

		return ret;
	}

}
