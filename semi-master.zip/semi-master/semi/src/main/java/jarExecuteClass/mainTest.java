package jarExecuteClass;

public class mainTest {

	public static void main(String[] args) {

		if (args.length != 4) {
			System.out.println("Wrong number of arguments");
			System.out.println("You need to provide 4 arguments: " + "\n1: programming language (java, c, cpp, f, f90)"
					+ "\n2: projectname" + "\n3: path to project directory" + "\n4: path to database credential file");
		}

		mainController controller = new mainController(args[0], args[1], args[2], args[3]);
		boolean result = controller.runExperiment();

		if (result) {
			System.out.println("Executed correctly");
			System.exit(0);
		} else {
			System.out.println("There was an error");
			System.exit(1);
		}

	}

}
